#ifndef DEF_BUFFER
#define DEF_BUFFER

#define BUFFER_SIZE 2048

#endif