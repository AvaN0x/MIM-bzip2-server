#ifndef DEF_FONT_COLORS
#define DEF_FONT_COLORS

#define FONT_DEFAULT "\033[0m"

#define FONT_RED "\033[0;31m"
#define FONT_GREEN "\033[0;32m"
#define FONT_YELLOW "\033[1;33m"
#define FONT_BLUE "\033[1;34m"
#define FONT_MAGENTA "\033[0;35m"

#endif