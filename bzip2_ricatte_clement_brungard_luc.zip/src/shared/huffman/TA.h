#ifndef TA_H
#define TA_H

#include <stdlib.h>

typedef unsigned int symbol_t;

typedef unsigned int frequence_t;

#endif
