#ifndef BWT_H
#define BWT_H

int encodeBWT(char *S, char *L);
void decodeBWT(char *SL, int len, int idx, char *outS);

#endif
