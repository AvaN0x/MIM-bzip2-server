#ifndef TEST_H
#define TEST_H

void testProcessFile();
void testRLE();
void testM2F();
void testHuffman();
void testBWT();

#endif